import gym
from RL_brain import PolicyGradient
import matplotlib.pyplot as plt

#在屏幕上显示模拟窗口会拖慢运行速度，等计算机学得差不多了再显示模拟
#当回合总reward大于400时显示模拟窗口
DISPLAY_REWARD_THRESHOLD = 400  # renders environment if total episode reward is greater then this threshold
RENDER = False  # rendering wastes time

#创建一个环境
env = gym.make('CartPole-v0')       #创建一个小车倒立摆模型
#普通的policy gradient方法使得回合的variance比较大，所以我们选了一个好点的随机种子
env.seed(1)     # reproducible, general Policy gradient has high variance
env = env.unwrapped             #取消限制

print(env.action_space)         #代理可用的action
print(env.observation_space)        #可能状态的总数
print(env.observation_space.high)   #observation最高值
print(env.observation_space.low)    #observation最低值

#定义
RL = PolicyGradient(
    n_actions=env.action_space.n,
    n_features=env.observation_space.shape[0],
    learning_rate=0.02,
    reward_decay=0.99,
    # output_graph=True,
)

#学习过程
for i_episode in range(3000):

    observation = env.reset()       #每次尝试都要到达终止状态. 一次尝试结束后重置环境的状态,返回观察

    while True:
        if RENDER: env.render()     #重绘环境的一帧,渲染出当前的智能体以及环境的状态

        action = RL.choose_action(observation)

        #推进一个时间步长
        #返回4个变量:新状态St+1,奖励Rt+1,一个布尔值（说明环境是否被终止或完成）以及额外的调试信息
        observation_, reward, done, info = env.step(action)

        RL.store_transition(observation, action, reward)#存储这一回合的transition

        if done:
            ep_rs_sum = sum(RL.ep_rs)

            if 'running_reward' not in globals():
                running_reward = ep_rs_sum
            else:
                running_reward = running_reward * 0.99 + ep_rs_sum * 0.01
            if running_reward > DISPLAY_REWARD_THRESHOLD: RENDER = True     # rendering判断是否显示模拟
            print("episode:", i_episode, "  reward:", int(running_reward))

            vt = RL.learn()     #学习,输出vt

            if i_episode == 0:
                plt.plot(vt)    # plot the episode vt
                plt.xlabel('episode steps')
                plt.ylabel('normalized state-action value')
                plt.show()
            break

        observation = observation_