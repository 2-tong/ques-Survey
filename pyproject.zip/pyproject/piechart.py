# -*- coding: UTF-8 -*-
import matplotlib.pyplot as plt
import MySQLdb

plt.rcParams['font.sans-serif']=['FangSong'] #用来正常显示中文标签
ques_id=109
sql1='SELECT option_survey.option_body, option_survey.option_count FROM option_survey \
WHERE option_survey.ques_id=%d'%(ques_id)

sql='SELECT SUM(option_count) FROM option_survey WHERE option_survey.ques_id=%d'%(ques_id)


db=MySQLdb.connect("localhost","root","123456","android_survey",charset="utf8")
cursor=db.cursor()
cursor.execute(sql1)
result=cursor.fetchall()
print result
cursor.execute(sql)
sum=cursor.fetchone()
print sum[0]

sizes = []
labels = []
for r in result:
    ji=100/sum[0]*r[1]
    sizes.append(ji)
    labels.append(r[0])

plt.pie(sizes,explode=None,labels=labels,autopct='%1.1f%%',shadow=False,startangle=90)
plt.axis('equal')
plt.savefig("pie.png")
plt.show()