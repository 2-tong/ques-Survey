import MySQLdb,decimal

ques_id=79
sql1='SELECT option_survey.option_count FROM option_survey WHERE option_survey.ques_id=%d'%(ques_id)

sql='SELECT SUM(option_count) FROM option_survey WHERE option_survey.ques_id=%d'%(ques_id)


db=MySQLdb.connect("localhost","root","123456","android_survey",charset="utf8")
cursor=db.cursor()
cursor.execute(sql1)
result=cursor.fetchall()
print result
cursor.execute(sql)
sum=cursor.fetchone()
print sum[0]

cha=[]
for r in result:
    ji=100*r[0]//sum[0]
    cha.append(ji)
print cha
big=max(cha)
small=min(cha)
print big,small
dic={"max":int(big),"min":int(small)}
print dic

