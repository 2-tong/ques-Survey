# -*- coding: UTF-8 -*-
import matplotlib.pyplot as plt
from PIL import Image
import numpy as np
import math

def ImageToMatrix(filename):
    # 读取图片
    im = Image.open(filename)
    # 显示图片
    # im.show()
    width, height = im.size
    im = im.convert("L")
    data = im.getdata()
    data = np.matrix(data, dtype='float') / 255.0
    new_data = np.reshape(data, (width, height))
    return new_data


#     new_im = Image.fromarray(new_data)
#     # 显示图片
#     new_im.show()
def MatrixToImage(data):
    data = data * 255
    new_im = Image.fromarray(data.astype(np.uint8))
    return new_im

def bfilter2(A,w,sigma):
    w=5
    sigma = [3, 0.1]
    x0=np.arange(-w,w,1)
    y0=np.arange(-w,w,1)
    [X,Y]=np.meshgrid(x0,y0)
    G=math.exp(-(X^2+Y^2))/(2*sigma[0]^2)

    dim=np.shape(A)
    B=np.zeros(dim)
    for i in range(dim[0]):
        for j in range(dim[1]):
            iMin=max(i-w,1)
            iMax=min(i+w,dim[0])
            jMin=max(j-w,1)
            jMax=min(j+w,dim[1])
            I=A[iMin-1:iMax,jMin-1:jMax]

            H=math.exp(-(I-A[i-1,j-1])^2/(2*sigma[1]^2))

    return A



data1 = ImageToMatrix('E:\matlab_demo\Bilateral Filtering/einstein.jpg')
#print data1
data1 = data1+0.03*np.random.randn(len(data1))
#print data1
data1[data1<0]=0
data1[data1>1]=1
print data1

w=5
sigma=[3,0.1]

bflt_data1=bfilter2(data1,w,sigma)

new_im1 = MatrixToImage(bflt_data1)
plt.imshow(bflt_data1, cmap=plt.cm.gray, interpolation='nearest')
new_im1.show()
new_im1.save('t_1.bmp')
