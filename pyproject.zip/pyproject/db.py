# -*- coding: UTF-8 -*-
import MySQLdb,json
import xlwt

filename = 'C:/Users/Lxy_1/Desktop/'+'sql1' + '.xls'
wbk = xlwt.Workbook()
sheet1 = wbk.add_sheet('sheet1', cell_overwrite_ok=True)
fileds = [u'题号', u'题目', u'被选次数']

sid=43
sql1='SELECT option_survey.option_body,option_survey.option_count,survey2ques.ques_order \
    FROM option_survey INNER JOIN survey2ques \
    ON option_survey.ques_id=survey2ques.ques_id WHERE option_survey.ques_id IN \
    (SELECT ques_id FROM survey2ques WHERE survey_id=%d)'%(sid)

sql2='SELECT answer_survey.`order`,answer_survey.answer_content FROM answer_survey WHERE answer_id IN \
    (SELECT answer_id FROM suvery2answer WHERE survey_id=%d) AND `order`IN (SELECT survey2ques.ques_order \
    FROM survey2ques INNER JOIN ques_survey ON survey2ques.ques_id = ques_survey.ques_id \
    WHERE ques_survey.ques_type="essay" AND survey_id =%d) ORDER BY `order`'%(sid,sid)

sql3='SELECT SUM(option_count) FROM option_survey WHERE option_survey.ques_id=%d)'%(sid)

db=MySQLdb.connect("localhost","root","123456","android_survey",charset="utf8")


cursor=db.cursor()

cursor.execute(sql1)
result=cursor.fetchall()
print result
for filed in range(0,len(fileds)):
     sheet1.write(0,filed,fileds[filed])
for row in range(1,len(result)+1):
     for col in range(0,len(fileds)):
          sheet1.write(row,col,result[row-1][col])
wbk.save(filename)
