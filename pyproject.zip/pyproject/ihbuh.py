# -*- coding: UTF-8 -*-
from flask import Flask, jsonify, request, abort,Response
import MySQLdb
import json
import datetime
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签

app = Flask(__name__)
db = MySQLdb.connect("localhost", "root", "123456", "android_survey", charset="utf8")
@app.route('/l',methods=['GET', 'POST'])
def hello_world():
    return 'Hello Flask!'

@app.route('/login/',methods=['POST'])
def login():
    data=request.get_data()
    j_d=json.loads(data)
    username = j_d['username']
    password = j_d['password']
    id=login_db(username,password)
    rdata = json.dumps({"id":id})
    print rdata
    return rdata
def login_db(name,psw):
    loginsql = 'SELECT user_survey.user_id, user_survey.`password` \
                FROM user_survey WHERE user_name ="%s"' \
               % (name)

    cursor = db.cursor()
    cursor.execute(loginsql)
    result = cursor.fetchone()
    if result == None:
        return -1
    if result[1]==psw:
        return result[0]
    return -1

@app.route('/registe/',methods=['POST'])
def registe():
    data = request.get_data()
    j_d = json.loads(data)
    username = j_d['username']
    password = j_d['password']
    success=registe_db(username,password)
    print success
    return success
def registe_db(name,psw):
    cursor = db.cursor()

    registesql1 = 'SELECT COUNT(*) FROM `user_survey` WHERE user_name="%s" '%(name)
    cursor.execute(registesql1)
    if(cursor.fetchone()[0]==0):

        registesql = 'INSERT INTO `android_survey`.`user_survey`(`user_name`, `password`) ' \
                     'VALUES ("%s", "%s")' \
                    %(name,psw)
        try:
            cursor.execute(registesql)
            db.commit()
            return "OK"
        except:
            db.rollback()
    else:
        return "REPEAT"

@app.route('/get_survey/',methods=['POST'])
def get_survey():
    data = request.get_data()
    j_d = json.loads(data)
    id = j_d['userid']
    print id
    sql2 =  'SELECT survey.survey_id, survey.suvery_title,survey.survey_count,survey.survey_post_time\
        ,survey.survey_status,survey.survey_except FROM survey WHERE survey.user_id = %d' %(id)

    cursor = db.cursor()
    cursor.execute(sql2)
    result = cursor.fetchall()
    print(result)
    list = []
    for row in result:
        dic = {"surveyid": row[0], "title": row[1], "count": row[2], "posttime": str(row[3]), "status": row[4],"except":row[5]}
        list.append(dic)
    print json.dumps(list).decode("unicode-escape")
    return json.dumps(list)

@app.route('/set_status/',methods=['POST'])
def set_status():
    data = request.get_data()
    print "set_sta:" + data
    j_d = json.loads(data)
    id = j_d['survey_id']
    status=j_d['status']
    print id
    print status
    cursor = db.cursor()
    if(status == 2):
        sql3='UPDATE `android_survey`.`survey` SET `survey_status` = "run" WHERE `survey_id` = %d'%(id)
        try:
            cursor.execute(sql3)
            sql='UPDATE `android_survey`.`survey` SET `survey_post_time` = (SELECT now()) WHERE `survey_id` = %d'%(id)
            cursor.execute(sql)
            db.commit()
            return "OK"
        except:
            db.rollback()
    if(status == 3):
        sql4='UPDATE `android_survey`.`survey` SET `survey_status` = "finish" WHERE `survey_id` = %d'%(id)
        try:
            cursor.execute(sql4)
            db.commit()
            return "OK"
        except:
            db.rollback()

@app.route('/delete_survey/',methods=['POST'])
def delete_survey():
    data = request.get_data()
    print "delete:"+data
    j_d = json.loads(data)
    id = j_d['survey_id']
    print id
    return delete(id)
def delete(s_id):
    cursor = db.cursor()
    #sql='DELETE FROM answer_survey WHERE answer_id IN (SELECT answer_id FROM suvery2answer WHERE survey_id = %d)'%(s_id)
    sql1='DELETE FROM suvery2answer WHERE `survey_id` = %d' % (s_id)
    sql5 = 'DELETE FROM ques_survey WHERE ques_id IN (SELECT ques_id FROM survey2ques WHERE survey_id = %d)' % (s_id)
    sql6 = 'DELETE FROM `android_survey`.`survey` WHERE `survey_id` = %d' % (s_id)
    try:
        #cursor.execute(sql)
        cursor.execute(sql1)
        cursor.execute(sql5)
        cursor.execute(sql6)
        db.commit()
        return "OK"
    except:
        db.rollback()

@app.route('/add_survey/',methods=['POST'])
def add_survey():
    starttime = datetime.datetime.now()

    # long running

    data = request.get_data()
    j_d = json.loads(data)
    if j_d["surveyID"]!=-1:
        delete(j_d["surveyID"])
    sql="INSERT INTO `android_survey`.`survey`(`suvery_title`, `user_id`,survey_except) VALUES ('%s', %d,%d)"\
    %(j_d["surveyname"],j_d["userid"],j_d["except"])

    crouse=db.cursor()
    try:
        crouse.execute(sql)
        db.commit()
        sid=getlast_insert()
        for ques in j_d["queslist"]:
            type='essay'
            if(ques["type"]!=0):
                if(ques["type"]==1):
                    type='single'
                else:
                    type='multi'
            crouse.execute(addques(ques["body"],type))
            db.commit()
            qid=getlast_insert()
            crouse.execute(addsurvey2ques(sid,qid,ques["order"]))
            if(ques["type"]!=0):
                for index in range(len(ques["options"])):
                    crouse.execute(addop(ques["options"][index],index,qid))
            db.commit()
    except:
        db.rollback()
    print j_d
    endtime = datetime.datetime.now()
    print (endtime - starttime).seconds
    return "OK"

def getlast_insert():
    sql="select last_insert_id()"
    crouse=db.cursor()
    crouse.execute(sql)
    return crouse.fetchone()[0]

def addop(body,order,ques_id):
    sql='INSERT INTO `android_survey`.`option_survey`(`option_body`, `ques_id`, `option_order`)\
     VALUES ("%s", %d, %d);'%(body,ques_id,order)
    return sql

def addques(body,type):
    sql='INSERT INTO `android_survey`.`ques_survey`( `ques_body`, `ques_type`) VALUES\
     ( "%s", "%s");'%(body,type)
    return sql

def addsurvey2ques(surveyid,quesid,quesorder):
    sql='INSERT INTO `android_survey`.`survey2ques`(`survey_id`, `ques_id`, `ques_order`) \
    VALUES (%d, %d, %d);'%(surveyid,quesid,quesorder)
    return sql

@app.route('/get_qlist/',methods=['POST'])
def get_qlist():
    data = request.get_data()
    j_d = json.loads(data)
    sid = j_d['surveyid']
    print sid
    sql1 = 'SELECT ques_survey.ques_id,ques_survey.ques_body,ques_survey.ques_type,survey2ques.ques_order FROM ques_survey\
     INNER JOIN survey2ques ON survey2ques.ques_id = ques_survey.ques_id\
     WHERE survey2ques.survey_id = %d ORDER BY survey2ques.ques_order' % (sid)

    sql2 = 'SELECT option_survey.option_body,option_survey.option_order,option_survey.ques_id FROM ques_survey\
     INNER JOIN option_survey ON option_survey.ques_id = ques_survey.ques_id\
     INNER JOIN survey2ques ON survey2ques.ques_id = ques_survey.ques_id\
     WHERE survey2ques.survey_id = %d ORDER BY survey2ques.ques_order,option_survey.option_order' % (sid)

    cursor = db.cursor()
    cursor.execute(sql1)
    result1 = cursor.fetchall()
    cursor.execute(sql2)
    result2 = cursor.fetchall()

    list = []
    index = 0
    for r in result1:
        if r[2] == "essay":
            dic = {"ques_id": r[0], "ques_body": r[1], "ques_type": r[2], "ques_order": r[3]}
        else:
            list1 = []
            while index < len(result2) and r[0] == result2[index][2]:
                w = result2[index]
                dic1 = {"op_body": w[0], "op_order": w[1]}
                list1.append(dic1)
                index += 1
            dic = {"ques_id": r[0], "ques_body": r[1], "ques_type": r[2], "ques_order": r[3], "options": list1}
        list.append(dic)

    print json.dumps(list).decode("unicode-escape")
    return json.dumps(list)

@app.route('/cmit_answer/',methods=['POST'])
def cmit_answer():
    data = request.get_data()
    j_d = json.loads(data)
    sid = j_d['surveyid']
    print sid
    print j_d
    sql='INSERT INTO `android_survey`.`suvery2answer`(`survey_id`) VALUES (%d)'%(sid)
    cursor = db.cursor()
    try:
        cursor.execute(sql)
        db.commit()
        aid = getlast_insert()
        for answer in j_d["alist"]:
            cursor.execute(insert_ques_answer(aid,answer["order"],answer["content"]))
        for option in  j_d["orderlist"]:
            cursor.execute(option_count(sid,option["order"],option["op_order"]))
        cursor.execute(survey_count(sid))
        db.commit()
    except:
        db.rollback()
    return "OK"

def option_count(sid,qorder,oporder):
    sql="""UPDATE option_survey
    SET option_count=option_count+1
    WHERE ques_id IN (SELECT survey2ques.ques_id FROM survey2ques WHERE survey2ques.survey_id=%d AND survey2ques.ques_order = %d) 
    AND option_order = %d""" %(sid,qorder,oporder)
    return sql

def survey_count(sid):
    sql='UPDATE `android_survey`.`survey` SET `survey_count` =`survey_count`+1 WHERE `survey_id` = %d'%(sid)
    return sql

def insert_ques_answer(aid,order,content):
    sql='INSERT INTO `android_survey`.`answer_survey`(`answer_id`, `order`, `answer_content`) \
    VALUES (%d, %d, "%s")'%(aid,order,content)
    return sql

@app.route('/analyze/',methods=['POST'])
def analyze():
    data = request.get_data()
    j_d = json.loads(data)
    sid = j_d['SurveyID']
    print sid
    sql1='SELECT option_survey.option_body,option_survey.option_count,survey2ques.ques_order \
    FROM option_survey INNER JOIN survey2ques \
    ON option_survey.ques_id=survey2ques.ques_id WHERE option_survey.ques_id IN \
    (SELECT ques_id FROM survey2ques WHERE survey_id=%d)'%(sid)

    sql2='SELECT answer_survey.answer_content,answer_survey.`order` FROM answer_survey WHERE answer_id IN \
    (SELECT answer_id FROM suvery2answer WHERE survey_id=%d) AND `order`IN (SELECT survey2ques.ques_order \
    FROM survey2ques INNER JOIN ques_survey ON survey2ques.ques_id = ques_survey.ques_id \
    WHERE ques_survey.ques_type="essay" AND survey_id =%d) ORDER BY `order`'%(sid,sid)

    cursor = db.cursor()
    cursor.execute(sql1)
    result1 = cursor.fetchall()
    cursor.execute(sql2)
    result2 = cursor.fetchall()

    list = []
    for r in result1:
        li=[]
        d={"option":r[0],"count":r[1]}
        li.append(d)
        dic={"order": r[2],"answer": li}
        list.append(dic)
    for w in result2:
        li = []
        d = {"option": w[0], "count": 1}
        li.append(d)
        dic = {"order": w[1], "answer": li}
        list.append(dic)

    print json.dumps(list).decode("unicode-escape")
    return json.dumps(list)

@app.route('/get_barchart/',methods=['POST'])
def barchart():
    data = request.get_data()
    j_d = json.loads(data)
    sid = j_d['survey_id']
    order = j_d['order']
    print sid

    sql2='SELECT ques_survey.ques_id FROM ques_survey WHERE ques_survey.ques_type != "essay" AND \
    ques_survey.ques_id IN(SELECT ques_id FROM survey2ques WHERE survey_id = %d AND survey2ques.ques_order=%d)'%(sid,order)

    cursor = db.cursor()

    cursor.execute(sql2)
    set= cursor.fetchone()
    ques_id = set[0]
    sql1 = 'SELECT option_survey.option_body, option_survey.option_count FROM option_survey \
    WHERE option_survey.ques_id=%d' % (ques_id)

    sql = 'SELECT SUM(option_count) FROM option_survey WHERE option_survey.ques_id=%d' % (ques_id)

    cursor.execute(sql1)
    result = cursor.fetchall()
    print result
    cursor.execute(sql)
    sum = cursor.fetchone()
    print sum[0]

    y = []
    index = []
    for r in result:
        ji = 100 / sum[0] * r[1]
        y.append(ji)
        index.append(r[0])

    plt.bar(range(len(y)), height=y, color='green', width=0.5,tick_label=index)
    plt.savefig("bar.png")
    #plt.show()
    plt.close('all')
    im=open("bar.png","rb")
    image=im.read()
    im.close()
    resp = Response(image, mimetype="image/png")
    return resp

@app.route('/get_piechart/',methods=['POST'])
def piechart():
    data = request.get_data()
    j_d = json.loads(data)
    sid = j_d['survey_id']
    order = j_d['order']
    print sid
    sql2 = 'SELECT ques_survey.ques_id FROM ques_survey WHERE ques_survey.ques_type != "essay" AND \
    ques_survey.ques_id IN(SELECT ques_id FROM survey2ques WHERE survey_id = %d AND survey2ques.ques_order=%d)'%(sid,order)

    cursor = db.cursor()
    cursor.execute(sql2)
    set = cursor.fetchone()
    ques_id = set[0]

    sql1 = 'SELECT option_survey.option_body, option_survey.option_count FROM option_survey \
    WHERE option_survey.ques_id=%d' % (ques_id)

    sql = 'SELECT SUM(option_count) FROM option_survey WHERE option_survey.ques_id=%d' % (ques_id)

    cursor.execute(sql1)
    result = cursor.fetchall()
    print result
    cursor.execute(sql)
    sum = cursor.fetchone()
    print sum[0]

    sizes = []
    labels = []
    for r in result:
        ji = 100 / sum[0] * r[1]
        sizes.append(ji)
        labels.append(r[0])

    plt.pie(sizes, explode=None, labels=labels, autopct='%1.1f%%', shadow=False, startangle=90)
    plt.axis('equal')
    plt.savefig("pie.png")
    #plt.show()
    plt.close('all')
    ima=open("pie.png","rb")
    imag=ima.read()
    ima.close()
    rsp = Response(imag, mimetype="image/png")
    return rsp

def ques_cha(ques_id):
    sql1 = 'SELECT option_survey.option_count FROM option_survey WHERE option_survey.ques_id=%d' % (ques_id)

    sql = 'SELECT SUM(option_count) FROM option_survey WHERE option_survey.ques_id=%d' % (ques_id)

    cursor = db.cursor()
    cursor.execute(sql1)
    result = cursor.fetchall()
    print result
    cursor.execute(sql)
    sum = cursor.fetchone()
    print sum[0]

    cha = []
    for r in result:
        ji = 100 * r[0] // sum[0]
        cha.append(ji)
    print cha
    big = max(cha)
    small = min(cha)
    print big, small
    dic = {"max": int(big), "min": int(small)}
    print dic
    return dic

@app.route('/get_chayi/',methods=['POST'])
def get_chayi():
    data = request.get_data()
    j_d = json.loads(data)
    sid = j_d['SurveyID']
    print sid

    sql2='SELECT survey2ques.ques_id, survey2ques.ques_order FROM survey2ques INNER JOIN ques_survey ON \
    survey2ques.ques_id = ques_survey.ques_id WHERE survey2ques.survey_id=%d AND ques_type!="essay"'%(sid)
    cursor = db.cursor()
    cursor.execute(sql2)
    result = cursor.fetchall()
    print result

    list=[]
    for r in result:
        cha=ques_cha(r[0])
        dic={"ques_order":r[1],"chayi":cha}
        list.append(dic)
    print list
    return json.dumps(list)

@app.route('/get_count/',methods=['POST'])
def get_count():
    data = request.get_data()
    j_d = json.loads(data)
    sid = j_d['SurveyID']
    print sid

    sql='SELECT survey.survey_count,survey.survey_except FROM survey WHERE survey.survey_id=%d'%(sid)
    cursor = db.cursor()
    cursor.execute(sql)
    count = cursor.fetchone()
    print count[0],count[1]
    return json.dumps({"count":count[0],"except":count[1]})

if __name__ == '__main__':
    print("hello")
    app.run("192.168.43.140",5000,True)